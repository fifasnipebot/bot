/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!*************************!*\
  !*** ./src/message.jsx ***!
  \*************************/
var checkTransferRoute = document.querySelector(".ut-tab-bar-item.icon-transfer.selected");
if (checkTransferRoute) {
  var div = document.createElement("div");
  div.innerHTML = "<div style=\"position: absolute; top: 20px; right: 20px; z-index:99; background-color: #fff; padding: 20px; border: 1px solid #ccc; border-radius: 5px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); max-width: 300px; text-align: center;\">\n  <div style=\"position: absolute; top: 10px; right: 10px; cursor: pointer; font-size: 20px; color: #999;\">&times;</div>\n  <p style=\"color:red;\">Your bot can only be used on ONE account which you initially registered with, please log back onto that account to continue using. If you need any other help then please contact us on instagram <a href=\"https://www.instagram.com/bakers.bot/\">Bakers Bot</a></p>\n  </div>";
  div.onclick = function () {
    div.remove();
  };
  var body = document.querySelector("body");
  body.setAttribute("position", "relative");
  body.appendChild(div);
}
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVzc2FnZS5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFBLElBQU1BLGtCQUFrQixHQUFHQyxRQUFRLENBQUNDLGFBQWEsQ0FBQyx5Q0FBeUMsQ0FBQztBQUU1RixJQUFHRixrQkFBa0IsRUFBQztFQUNwQixJQUFNRyxHQUFHLEdBQUdGLFFBQVEsQ0FBQ0csYUFBYSxDQUFDLEtBQUssQ0FBQztFQUN6Q0QsR0FBRyxDQUFDRSxTQUFTLHFwQkFHTjtFQUVQRixHQUFHLENBQUNHLE9BQU8sR0FBRyxZQUFNO0lBQ2xCSCxHQUFHLENBQUNJLE1BQU0sQ0FBQyxDQUFDO0VBQ2QsQ0FBQztFQUVELElBQU1DLElBQUksR0FBR1AsUUFBUSxDQUFDQyxhQUFhLENBQUMsTUFBTSxDQUFDO0VBQzNDTSxJQUFJLENBQUNDLFlBQVksQ0FBQyxVQUFVLEVBQUMsVUFBVSxDQUFDO0VBQ3hDRCxJQUFJLENBQUNFLFdBQVcsQ0FBQ1AsR0FBRyxDQUFDO0FBQ3ZCLEMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ndWlsbGF1bWViYXIzMjIvLi9zcmMvbWVzc2FnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgY2hlY2tUcmFuc2ZlclJvdXRlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi51dC10YWItYmFyLWl0ZW0uaWNvbi10cmFuc2Zlci5zZWxlY3RlZFwiKVxuXG5pZihjaGVja1RyYW5zZmVyUm91dGUpe1xuICBjb25zdCBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpXG4gIGRpdi5pbm5lckhUTUwgPSBgPGRpdiBzdHlsZT1cInBvc2l0aW9uOiBhYnNvbHV0ZTsgdG9wOiAyMHB4OyByaWdodDogMjBweDsgei1pbmRleDo5OTsgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjsgcGFkZGluZzogMjBweDsgYm9yZGVyOiAxcHggc29saWQgI2NjYzsgYm9yZGVyLXJhZGl1czogNXB4OyBib3gtc2hhZG93OiAwIDAgMTBweCByZ2JhKDAsIDAsIDAsIDAuMik7IG1heC13aWR0aDogMzAwcHg7IHRleHQtYWxpZ246IGNlbnRlcjtcIj5cbiAgPGRpdiBzdHlsZT1cInBvc2l0aW9uOiBhYnNvbHV0ZTsgdG9wOiAxMHB4OyByaWdodDogMTBweDsgY3Vyc29yOiBwb2ludGVyOyBmb250LXNpemU6IDIwcHg7IGNvbG9yOiAjOTk5O1wiPiZ0aW1lczs8L2Rpdj5cbiAgPHAgc3R5bGU9XCJjb2xvcjpyZWQ7XCI+WW91ciBib3QgY2FuIG9ubHkgYmUgdXNlZCBvbiBPTkUgYWNjb3VudCB3aGljaCB5b3UgaW5pdGlhbGx5IHJlZ2lzdGVyZWQgd2l0aCwgcGxlYXNlIGxvZyBiYWNrIG9udG8gdGhhdCBhY2NvdW50IHRvIGNvbnRpbnVlIHVzaW5nLiBJZiB5b3UgbmVlZCBhbnkgb3RoZXIgaGVscCB0aGVuIHBsZWFzZSBjb250YWN0IHVzIG9uIGluc3RhZ3JhbSA8YSBocmVmPVwiaHR0cHM6Ly93d3cuaW5zdGFncmFtLmNvbS9iYWtlcnMuYm90L1wiPkJha2VycyBCb3Q8L2E+PC9wPlxuICA8L2Rpdj5gXG4gIFxuICBkaXYub25jbGljayA9ICgpID0+IHtcbiAgICBkaXYucmVtb3ZlKCk7XG4gIH1cbiAgXG4gIGNvbnN0IGJvZHkgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiYm9keVwiKSA7XG4gIGJvZHkuc2V0QXR0cmlidXRlKFwicG9zaXRpb25cIixcInJlbGF0aXZlXCIpO1xuICBib2R5LmFwcGVuZENoaWxkKGRpdik7ICBcbn0iXSwibmFtZXMiOlsiY2hlY2tUcmFuc2ZlclJvdXRlIiwiZG9jdW1lbnQiLCJxdWVyeVNlbGVjdG9yIiwiZGl2IiwiY3JlYXRlRWxlbWVudCIsImlubmVySFRNTCIsIm9uY2xpY2siLCJyZW1vdmUiLCJib2R5Iiwic2V0QXR0cmlidXRlIiwiYXBwZW5kQ2hpbGQiXSwic291cmNlUm9vdCI6IiJ9