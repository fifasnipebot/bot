/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!*************************!*\
  !*** ./src/reroute.jsx ***!
  \*************************/
var checkListRoute = document.querySelector(".ut-tab-bar-item");
if (checkListRoute) {
  var div = document.createElement("div");
  div.innerHTML = "<div style=\"position: absolute; top: 20px; right: 20px; z-index:99; background-color: #fff; padding: 20px; border: 1px solid #ccc; border-radius: 5px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); max-width: 300px; text-align: center;\">\n  <div style=\"position: absolute; top: 10px; right: 10px; cursor: pointer; font-size: 20px; color: #999;\">&times;</div>\n  <p style=\"color:black;\">Please make sure you are on the search page of the transfer market itself.</p>\n  </div>";
  div.onclick = function () {
    div.remove();
  };
  var body = document.querySelector("body");
  body.setAttribute("position", "relative");
  body.appendChild(div);
}
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVyb3V0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFBLElBQU1BLGNBQWMsR0FBR0MsUUFBUSxDQUFDQyxhQUFhLENBQUMsa0JBQWtCLENBQUM7QUFFakUsSUFBR0YsY0FBYyxFQUFDO0VBQ2hCLElBQU1HLEdBQUcsR0FBR0YsUUFBUSxDQUFDRyxhQUFhLENBQUMsS0FBSyxDQUFDO0VBQ3pDRCxHQUFHLENBQUNFLFNBQVMsK2RBR047RUFFUEYsR0FBRyxDQUFDRyxPQUFPLEdBQUcsWUFBTTtJQUNsQkgsR0FBRyxDQUFDSSxNQUFNLENBQUMsQ0FBQztFQUNkLENBQUM7RUFFRCxJQUFNQyxJQUFJLEdBQUdQLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLE1BQU0sQ0FBQztFQUMzQ00sSUFBSSxDQUFDQyxZQUFZLENBQUMsVUFBVSxFQUFDLFVBQVUsQ0FBQztFQUN4Q0QsSUFBSSxDQUFDRSxXQUFXLENBQUNQLEdBQUcsQ0FBQztBQUN2QixDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZ3VpbGxhdW1lYmFyMzIyLy4vc3JjL3Jlcm91dGUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IGNoZWNrTGlzdFJvdXRlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi51dC10YWItYmFyLWl0ZW1cIilcclxuXHJcbmlmKGNoZWNrTGlzdFJvdXRlKXtcclxuICBjb25zdCBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpXHJcbiAgZGl2LmlubmVySFRNTCA9IGA8ZGl2IHN0eWxlPVwicG9zaXRpb246IGFic29sdXRlOyB0b3A6IDIwcHg7IHJpZ2h0OiAyMHB4OyB6LWluZGV4Ojk5OyBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmOyBwYWRkaW5nOiAyMHB4OyBib3JkZXI6IDFweCBzb2xpZCAjY2NjOyBib3JkZXItcmFkaXVzOiA1cHg7IGJveC1zaGFkb3c6IDAgMCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yKTsgbWF4LXdpZHRoOiAzMDBweDsgdGV4dC1hbGlnbjogY2VudGVyO1wiPlxyXG4gIDxkaXYgc3R5bGU9XCJwb3NpdGlvbjogYWJzb2x1dGU7IHRvcDogMTBweDsgcmlnaHQ6IDEwcHg7IGN1cnNvcjogcG9pbnRlcjsgZm9udC1zaXplOiAyMHB4OyBjb2xvcjogIzk5OTtcIj4mdGltZXM7PC9kaXY+XHJcbiAgPHAgc3R5bGU9XCJjb2xvcjpibGFjaztcIj5QbGVhc2UgbWFrZSBzdXJlIHlvdSBhcmUgb24gdGhlIHNlYXJjaCBwYWdlIG9mIHRoZSB0cmFuc2ZlciBtYXJrZXQgaXRzZWxmLjwvcD5cclxuICA8L2Rpdj5gXHJcbiAgXHJcbiAgZGl2Lm9uY2xpY2sgPSAoKSA9PiB7XHJcbiAgICBkaXYucmVtb3ZlKCk7XHJcbiAgfVxyXG4gIFxyXG4gIGNvbnN0IGJvZHkgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiYm9keVwiKSA7XHJcbiAgYm9keS5zZXRBdHRyaWJ1dGUoXCJwb3NpdGlvblwiLFwicmVsYXRpdmVcIik7XHJcbiAgYm9keS5hcHBlbmRDaGlsZChkaXYpO1xyXG59XHJcblxyXG5cclxuXHJcbiJdLCJuYW1lcyI6WyJjaGVja0xpc3RSb3V0ZSIsImRvY3VtZW50IiwicXVlcnlTZWxlY3RvciIsImRpdiIsImNyZWF0ZUVsZW1lbnQiLCJpbm5lckhUTUwiLCJvbmNsaWNrIiwicmVtb3ZlIiwiYm9keSIsInNldEF0dHJpYnV0ZSIsImFwcGVuZENoaWxkIl0sInNvdXJjZVJvb3QiOiIifQ==