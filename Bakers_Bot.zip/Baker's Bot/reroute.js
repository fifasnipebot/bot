/******/ (function() { // webpackBootstrap
/*!*************************!*\
  !*** ./src/reroute.jsx ***!
  \*************************/
var checkListRoute = document.querySelector(".ut-tab-bar-item");
if (checkListRoute) {
  var div = document.createElement("div");
  div.innerHTML = "<div style=\"position: absolute; top: 20px; right: 20px; z-index:99; background-color: #fff; padding: 20px; border: 1px solid #ccc; border-radius: 5px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); max-width: 300px; text-align: center;\">\n  <div style=\"position: absolute; top: 10px; right: 10px; cursor: pointer; font-size: 20px; color: #999;\">&times;</div>\n  <p style=\"color:black;\">Please make sure you are on the search page of the transfer market itself.</p>\n  </div>";
  div.onclick = function () {
    div.remove();
  };
  var body = document.querySelector("body");
  body.setAttribute("position", "relative");
  body.appendChild(div);
}
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVyb3V0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7O0FBQUEsSUFBTUEsY0FBYyxHQUFHQyxRQUFRLENBQUNDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQztBQUVqRSxJQUFHRixjQUFjLEVBQUM7RUFDaEIsSUFBTUcsR0FBRyxHQUFHRixRQUFRLENBQUNHLGFBQWEsQ0FBQyxLQUFLLENBQUM7RUFDekNELEdBQUcsQ0FBQ0UsU0FBUywrZEFHTjtFQUVQRixHQUFHLENBQUNHLE9BQU8sR0FBRyxZQUFNO0lBQ2xCSCxHQUFHLENBQUNJLE1BQU0sQ0FBQyxDQUFDO0VBQ2QsQ0FBQztFQUVELElBQU1DLElBQUksR0FBR1AsUUFBUSxDQUFDQyxhQUFhLENBQUMsTUFBTSxDQUFDO0VBQzNDTSxJQUFJLENBQUNDLFlBQVksQ0FBQyxVQUFVLEVBQUMsVUFBVSxDQUFDO0VBQ3hDRCxJQUFJLENBQUNFLFdBQVcsQ0FBQ1AsR0FBRyxDQUFDO0FBQ3ZCLEMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ndWlsbGF1bWViYXIzMjIvLi9zcmMvcmVyb3V0ZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgY2hlY2tMaXN0Um91dGUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLnV0LXRhYi1iYXItaXRlbVwiKVxyXG5cclxuaWYoY2hlY2tMaXN0Um91dGUpe1xyXG4gIGNvbnN0IGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIilcclxuICBkaXYuaW5uZXJIVE1MID0gYDxkaXYgc3R5bGU9XCJwb3NpdGlvbjogYWJzb2x1dGU7IHRvcDogMjBweDsgcmlnaHQ6IDIwcHg7IHotaW5kZXg6OTk7IGJhY2tncm91bmQtY29sb3I6ICNmZmY7IHBhZGRpbmc6IDIwcHg7IGJvcmRlcjogMXB4IHNvbGlkICNjY2M7IGJvcmRlci1yYWRpdXM6IDVweDsgYm94LXNoYWRvdzogMCAwIDEwcHggcmdiYSgwLCAwLCAwLCAwLjIpOyBtYXgtd2lkdGg6IDMwMHB4OyB0ZXh0LWFsaWduOiBjZW50ZXI7XCI+XHJcbiAgPGRpdiBzdHlsZT1cInBvc2l0aW9uOiBhYnNvbHV0ZTsgdG9wOiAxMHB4OyByaWdodDogMTBweDsgY3Vyc29yOiBwb2ludGVyOyBmb250LXNpemU6IDIwcHg7IGNvbG9yOiAjOTk5O1wiPiZ0aW1lczs8L2Rpdj5cclxuICA8cCBzdHlsZT1cImNvbG9yOmJsYWNrO1wiPlBsZWFzZSBtYWtlIHN1cmUgeW91IGFyZSBvbiB0aGUgc2VhcmNoIHBhZ2Ugb2YgdGhlIHRyYW5zZmVyIG1hcmtldCBpdHNlbGYuPC9wPlxyXG4gIDwvZGl2PmBcclxuICBcclxuICBkaXYub25jbGljayA9ICgpID0+IHtcclxuICAgIGRpdi5yZW1vdmUoKTtcclxuICB9XHJcbiAgXHJcbiAgY29uc3QgYm9keSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJib2R5XCIpIDtcclxuICBib2R5LnNldEF0dHJpYnV0ZShcInBvc2l0aW9uXCIsXCJyZWxhdGl2ZVwiKTtcclxuICBib2R5LmFwcGVuZENoaWxkKGRpdik7XHJcbn1cclxuXHJcblxyXG5cclxuIl0sIm5hbWVzIjpbImNoZWNrTGlzdFJvdXRlIiwiZG9jdW1lbnQiLCJxdWVyeVNlbGVjdG9yIiwiZGl2IiwiY3JlYXRlRWxlbWVudCIsImlubmVySFRNTCIsIm9uY2xpY2siLCJyZW1vdmUiLCJib2R5Iiwic2V0QXR0cmlidXRlIiwiYXBwZW5kQ2hpbGQiXSwic291cmNlUm9vdCI6IiJ9