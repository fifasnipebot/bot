/******/ (function() { // webpackBootstrap
/*!*********************************!*\
  !*** ./src/versionMismatch.jsx ***!
  \*********************************/
var checkListRoute = document.querySelector(".ut-tab-bar-item");
if (checkListRoute) {
  var div = document.createElement("div");
  div.innerHTML = "<div style=\"position: absolute; top: 20px; right: 20px; z-index:99; background-color: #fff; padding: 20px; border: 1px solid #ccc; border-radius: 5px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); max-width: 300px; text-align: center;\">\n  <div style=\"position: absolute; top: 10px; right: 10px; cursor: pointer; font-size: 20px; color: #999;\">&times;</div>\n  <p style=\"color:black;\">Please update your extension to latest version. <a href=\"https://fifasnipebot.com/dashboard\">Download</a></p>\n  </div>";
  div.onclick = function () {
    div.remove();
  };
  var body = document.querySelector("body");
  body.setAttribute("position", "relative");
  body.appendChild(div);
}
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmVyc2lvbk1pc21hdGNoLmpzIiwibWFwcGluZ3MiOiI7Ozs7QUFBQSxJQUFNQSxjQUFjLEdBQUdDLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLGtCQUFrQixDQUFDO0FBRWpFLElBQUdGLGNBQWMsRUFBRTtFQUVqQixJQUFNRyxHQUFHLEdBQUdGLFFBQVEsQ0FBQ0csYUFBYSxDQUFDLEtBQUssQ0FBQztFQUN6Q0QsR0FBRyxDQUFDRSxTQUFTLGdnQkFHTjtFQUVQRixHQUFHLENBQUNHLE9BQU8sR0FBRyxZQUFNO0lBQ2xCSCxHQUFHLENBQUNJLE1BQU0sQ0FBQyxDQUFDO0VBQ2QsQ0FBQztFQUVELElBQU1DLElBQUksR0FBR1AsUUFBUSxDQUFDQyxhQUFhLENBQUMsTUFBTSxDQUFDO0VBQzNDTSxJQUFJLENBQUNDLFlBQVksQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDO0VBQ3pDRCxJQUFJLENBQUNFLFdBQVcsQ0FBQ1AsR0FBRyxDQUFDO0FBQ3ZCLEMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ndWlsbGF1bWViYXIzMjIvLi9zcmMvdmVyc2lvbk1pc21hdGNoLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBjaGVja0xpc3RSb3V0ZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIudXQtdGFiLWJhci1pdGVtXCIpXHJcblxyXG5pZihjaGVja0xpc3RSb3V0ZSkge1xyXG5cclxuICBjb25zdCBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpXHJcbiAgZGl2LmlubmVySFRNTCA9IGA8ZGl2IHN0eWxlPVwicG9zaXRpb246IGFic29sdXRlOyB0b3A6IDIwcHg7IHJpZ2h0OiAyMHB4OyB6LWluZGV4Ojk5OyBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmOyBwYWRkaW5nOiAyMHB4OyBib3JkZXI6IDFweCBzb2xpZCAjY2NjOyBib3JkZXItcmFkaXVzOiA1cHg7IGJveC1zaGFkb3c6IDAgMCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yKTsgbWF4LXdpZHRoOiAzMDBweDsgdGV4dC1hbGlnbjogY2VudGVyO1wiPlxyXG4gIDxkaXYgc3R5bGU9XCJwb3NpdGlvbjogYWJzb2x1dGU7IHRvcDogMTBweDsgcmlnaHQ6IDEwcHg7IGN1cnNvcjogcG9pbnRlcjsgZm9udC1zaXplOiAyMHB4OyBjb2xvcjogIzk5OTtcIj4mdGltZXM7PC9kaXY+XHJcbiAgPHAgc3R5bGU9XCJjb2xvcjpibGFjaztcIj5QbGVhc2UgdXBkYXRlIHlvdXIgZXh0ZW5zaW9uIHRvIGxhdGVzdCB2ZXJzaW9uLiA8YSBocmVmPVwiaHR0cHM6Ly9maWZhc25pcGVib3QuY29tL2Rhc2hib2FyZFwiPkRvd25sb2FkPC9hPjwvcD5cclxuICA8L2Rpdj5gXHJcblxyXG4gIGRpdi5vbmNsaWNrID0gKCkgPT4ge1xyXG4gICAgZGl2LnJlbW92ZSgpO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgYm9keSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJib2R5XCIpO1xyXG4gIGJvZHkuc2V0QXR0cmlidXRlKFwicG9zaXRpb25cIiwgXCJyZWxhdGl2ZVwiKTtcclxuICBib2R5LmFwcGVuZENoaWxkKGRpdik7XHJcbn1cclxuXHJcblxyXG4iXSwibmFtZXMiOlsiY2hlY2tMaXN0Um91dGUiLCJkb2N1bWVudCIsInF1ZXJ5U2VsZWN0b3IiLCJkaXYiLCJjcmVhdGVFbGVtZW50IiwiaW5uZXJIVE1MIiwib25jbGljayIsInJlbW92ZSIsImJvZHkiLCJzZXRBdHRyaWJ1dGUiLCJhcHBlbmRDaGlsZCJdLCJzb3VyY2VSb290IjoiIn0=