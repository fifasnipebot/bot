/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!***************************!*\
  !*** ./src/subscribe.jsx ***!
  \***************************/
var checkTransferRoute = document.querySelector(".ut-tab-bar-item.icon-transfer.selected");
if (checkTransferRoute) {
  var div = document.createElement("div");
  div.innerHTML = "<div style=\"position: absolute; top: 20px; right: 20px; z-index:99; background-color: #fff; padding: 20px; border: 1px solid #ccc; border-radius: 5px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); max-width: 300px; text-align: center;\"><div style=\"position: absolute; top: 10px; right: 10px; cursor: pointer; font-size: 20px; color: #999;\">&times;</div><p style=\"color:red;\">Your subscription has expired as it has been one year since you purchased the bot! If you would like to renew then please contact us on Instagram <a href=\"https://www.instagram.com/bakers.bot/\">Bakers Bot</a></p></div>";
  div.onclick = function () {
    div.remove();
  };
  var body = document.querySelector("body");
  body.setAttribute("position", "relative");
  body.appendChild(div);
}
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3Vic2NyaWJlLmpzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsSUFBTUEsa0JBQWtCLEdBQUdDLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLHlDQUF5QyxDQUFDO0FBRTVGLElBQUdGLGtCQUFrQixFQUFFO0VBQ25CLElBQU1HLEdBQUcsR0FBR0YsUUFBUSxDQUFDRyxhQUFhLENBQUMsS0FBSyxDQUFDO0VBQ3pDRCxHQUFHLENBQUNFLFNBQVMseWxCQUFpbEI7RUFFOWxCRixHQUFHLENBQUNHLE9BQU8sR0FBRyxZQUFNO0lBQ2hCSCxHQUFHLENBQUNJLE1BQU0sQ0FBQyxDQUFDO0VBQ2hCLENBQUM7RUFFRCxJQUFNQyxJQUFJLEdBQUdQLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLE1BQU0sQ0FBQztFQUMzQ00sSUFBSSxDQUFDQyxZQUFZLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQztFQUN6Q0QsSUFBSSxDQUFDRSxXQUFXLENBQUNQLEdBQUcsQ0FBQztBQUN6QixDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZ3VpbGxhdW1lYmFyMzIyLy4vc3JjL3N1YnNjcmliZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgY2hlY2tUcmFuc2ZlclJvdXRlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi51dC10YWItYmFyLWl0ZW0uaWNvbi10cmFuc2Zlci5zZWxlY3RlZFwiKVxuXG5pZihjaGVja1RyYW5zZmVyUm91dGUpIHtcbiAgICBjb25zdCBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpXG4gICAgZGl2LmlubmVySFRNTCA9IGA8ZGl2IHN0eWxlPVwicG9zaXRpb246IGFic29sdXRlOyB0b3A6IDIwcHg7IHJpZ2h0OiAyMHB4OyB6LWluZGV4Ojk5OyBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmOyBwYWRkaW5nOiAyMHB4OyBib3JkZXI6IDFweCBzb2xpZCAjY2NjOyBib3JkZXItcmFkaXVzOiA1cHg7IGJveC1zaGFkb3c6IDAgMCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yKTsgbWF4LXdpZHRoOiAzMDBweDsgdGV4dC1hbGlnbjogY2VudGVyO1wiPjxkaXYgc3R5bGU9XCJwb3NpdGlvbjogYWJzb2x1dGU7IHRvcDogMTBweDsgcmlnaHQ6IDEwcHg7IGN1cnNvcjogcG9pbnRlcjsgZm9udC1zaXplOiAyMHB4OyBjb2xvcjogIzk5OTtcIj4mdGltZXM7PC9kaXY+PHAgc3R5bGU9XCJjb2xvcjpyZWQ7XCI+WW91ciBzdWJzY3JpcHRpb24gaGFzIGV4cGlyZWQgYXMgaXQgaGFzIGJlZW4gb25lIHllYXIgc2luY2UgeW91IHB1cmNoYXNlZCB0aGUgYm90ISBJZiB5b3Ugd291bGQgbGlrZSB0byByZW5ldyB0aGVuIHBsZWFzZSBjb250YWN0IHVzIG9uIEluc3RhZ3JhbSA8YSBocmVmPVwiaHR0cHM6Ly93d3cuaW5zdGFncmFtLmNvbS9iYWtlcnMuYm90L1wiPkJha2VycyBCb3Q8L2E+PC9wPjwvZGl2PmBcblxuICAgIGRpdi5vbmNsaWNrID0gKCkgPT4ge1xuICAgICAgICBkaXYucmVtb3ZlKCk7XG4gICAgfVxuXG4gICAgY29uc3QgYm9keSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJib2R5XCIpO1xuICAgIGJvZHkuc2V0QXR0cmlidXRlKFwicG9zaXRpb25cIiwgXCJyZWxhdGl2ZVwiKTtcbiAgICBib2R5LmFwcGVuZENoaWxkKGRpdik7XG59Il0sIm5hbWVzIjpbImNoZWNrVHJhbnNmZXJSb3V0ZSIsImRvY3VtZW50IiwicXVlcnlTZWxlY3RvciIsImRpdiIsImNyZWF0ZUVsZW1lbnQiLCJpbm5lckhUTUwiLCJvbmNsaWNrIiwicmVtb3ZlIiwiYm9keSIsInNldEF0dHJpYnV0ZSIsImFwcGVuZENoaWxkIl0sInNvdXJjZVJvb3QiOiIifQ==